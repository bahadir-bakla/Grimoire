import './assets/service-worker.js--1-RnqF7.js';
