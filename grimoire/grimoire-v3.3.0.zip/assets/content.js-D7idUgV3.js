import{M as y,D as b,a as h,X as g}from"./constants-BU5Rw-UW.js";console.log("[Grimoire] Content script loaded:",window.location.href);chrome.runtime.onMessage.addListener((e,t,n)=>(console.log("[Grimoire CS] Message received:",e.type),e.type===y.MONSTER_ATTACK&&(x(e),n({ok:!0})),e.type==="WEEKLY_BOSS"&&(E(e),n({ok:!0})),!0));function x(e){var s;(s=document.getElementById("gr-monster"))==null||s.remove();const{monster:t,xpLost:n,remainingXP:o}=e,r=document.createElement("div");r.id="gr-monster",r.innerHTML=`
    <div class="gr-monster-inner">
      <div class="gr-monster-eyebrow">${t.title}</div>
      <div class="gr-monster-name">${t.name}</div>
      <div class="gr-monster-msg">${t.message}</div>
      <div class="gr-monster-xp">
        <span class="gr-xp-lost">−${n} XP</span>
        <span class="gr-xp-remaining">Kalan: ${o} XP</span>
      </div>
      <div class="gr-monster-hp-wrap">
        <div class="gr-monster-hp-bar" id="gr-hp-bar"></div>
      </div>
      <button class="gr-monster-dismiss" id="gr-monster-ok">
        Anladım, geri dönüyorum
      </button>
    </div>
  `,document.body.appendChild(r),requestAnimationFrame(()=>{const d=document.getElementById("gr-hp-bar");d&&(d.style.width="100%")}),document.getElementById("gr-monster-ok").addEventListener("click",()=>{r.classList.add("gr-monster-leaving"),setTimeout(()=>r.remove(),300)});const a=setTimeout(()=>{r.classList.add("gr-monster-leaving"),setTimeout(()=>r.remove(),300)},1e4);document.getElementById("gr-monster-ok").addEventListener("click",()=>{clearTimeout(a)},{once:!0})}function E(e){const{boss:t,weeklyScrolls:n,winXP:o}=e,r=document.createElement("div");r.id="gr-boss",r.innerHTML=`
    <div class="gr-boss-inner">
      <div class="gr-boss-label">HAFTALIK YÜZLEŞME</div>
      <div class="gr-boss-name">${t.name}</div>
      <div class="gr-boss-stats">
        Bu hafta ${n} scroll tamamladın.
        Boss HP: ${t.hp}/100
      </div>
      <div class="gr-boss-hp-track">
        <div class="gr-boss-hp-fill" style="width:${t.hp}%"></div>
      </div>
      <div class="gr-boss-actions">
        <button class="gr-boss-fight" id="gr-boss-fight">Savaş (+${o} XP)</button>
        <button class="gr-boss-flee" id="gr-boss-flee">Kaç</button>
      </div>
      <div class="gr-boss-result" id="gr-boss-result" style="display:none"></div>
    </div>
  `,document.body.appendChild(r),document.getElementById("gr-boss-fight").addEventListener("click",async()=>{const a=Math.min(.9,n*.08+.2),s=Math.random()<a;document.getElementById("gr-boss-fight").disabled=!0,document.getElementById("gr-boss-flee").disabled=!0;const d=document.getElementById("gr-boss-result");d.style.display="block",s?(d.innerHTML=`
        <div class="gr-boss-win">
          Zafer! +${o} XP kazandın.<br>
          <small>Haftalık boss yenildi.</small>
        </div>
      `,await chrome.runtime.sendMessage({type:"BOSS_RESULT",won:!0,xpChange:o})):(d.innerHTML=`
        <div class="gr-boss-loss">
          Yenildin. XP'nin %20'si silindi.<br>
          <small>Gelecek hafta daha güçlü ol.</small>
        </div>
      `,await chrome.runtime.sendMessage({type:"BOSS_RESULT",won:!1,xpChange:0})),setTimeout(()=>{r.classList.add("gr-monster-leaving"),setTimeout(()=>r.remove(),300)},3e3)}),document.getElementById("gr-boss-flee").addEventListener("click",()=>{r.classList.add("gr-monster-leaving"),setTimeout(()=>r.remove(),300)})}function C(){const e=["article","main",'[role="main"]',".post-content",".article-content",".entry-content","#content"];let t=null;for(const a of e)if(t=document.querySelector(a),t)break;t=t??document.body;const n=t.cloneNode(!0);return["script","style","nav","footer","header","aside",".sidebar",".ad",".advertisement",".cookie-banner",".popup",'[aria-hidden="true"]'].forEach(a=>{n.querySelectorAll(a).forEach(s=>s.remove())}),(n.innerText??n.textContent??"").replace(/\s+/g," ").trim().slice(0,15e3)}function B(){return document.getElementById("gr-sidebar")}function L(){if(B())return;const e=document.createElement("div");e.id="gr-sidebar",e.innerHTML=`
    <div class="gr-sidebar-header">
      <span class="gr-sidebar-title">GRIMOIRE</span>
      <button class="gr-sidebar-close" id="gr-close" title="Kapat">×</button>
    </div>
    <div class="gr-sidebar-body" id="gr-body">
      <div class="gr-loading" id="gr-loading">
        <div class="gr-loading-dot"></div>
        <div class="gr-loading-dot"></div>
        <div class="gr-loading-dot"></div>
      </div>
      <div class="gr-lore-text" id="gr-lore" style="display:none"></div>
      <div class="gr-error" id="gr-error" style="display:none"></div>
    </div>
    <div class="gr-sidebar-footer" id="gr-footer" style="display:none">
      <div style="display:flex; gap:8px; margin-bottom:8px;">
        <button class="gr-save-btn" id="gr-save" style="flex:1">Grimoire'a Kaydet</button>
        <button id="gr-mode-toggle" style="flex:1; background:rgba(83,74,183,.2); border:1px solid rgba(83,74,183,.4); color:#afa9ec; border-radius:7px; font-size:12px; font-weight:500; cursor:pointer;" title="Hikaye ve Resmi Özet arasında geçiş yap">
          Resmi Özete Geç
        </button>
      </div>
      <div class="gr-xp-preview" id="gr-xp-preview"></div>
    </div>
  `,document.body.appendChild(e),document.getElementById("gr-close").addEventListener("click",()=>{e.classList.add("gr-sidebar-closing"),setTimeout(()=>e.remove(),250)})}function P(){document.getElementById("gr-loading").style.display="flex",document.getElementById("gr-lore").style.display="none",document.getElementById("gr-error").style.display="none",document.getElementById("gr-footer").style.display="none"}function v(e,t){document.getElementById("gr-loading").style.display="none",document.getElementById("gr-error").style.display="none";const n=document.getElementById("gr-lore");n.style.display="block";const o=e.split(`

`).filter(Boolean);n.innerHTML=o.map(r=>`<p>${r.trim()}</p>`).join(""),document.getElementById("gr-footer").style.display="block",document.getElementById("gr-xp-preview").textContent=`+${t} XP kazanacaksın`}function k(e){document.getElementById("gr-loading").style.display="none",document.getElementById("gr-lore").style.display="none";const t=document.getElementById("gr-error");t.style.display="block",t.textContent=e}function I(){const e=document.body.scrollHeight-window.innerHeight,t=e>0?Math.min(100,window.scrollY/e*100):50;return Math.floor(100+t*3)}let f=null,M=Date.now();async function w(){var p;const e=window.location.href;if(e.startsWith("chrome://")||e.startsWith("chrome-extension://")||e.startsWith("about:")||e.startsWith("data:")||b.some(i=>e.includes(i)))return;const{session:n}=await chrome.storage.local.get(["session"]);if(!(n!=null&&n.isActive))return;window.grCurrentMode=n.mode||"lore",f=document.title.slice(0,80),L();const{grimoire:o}=await chrome.storage.local.get(["grimoire"]),r=(o??[]).find(i=>i.url===e);if(r){v(r.loreText,0);const i=document.getElementById("gr-save");i&&(i.textContent="Zaten Grimoire'da",i.disabled=!0,i.style.opacity="0.5"),(p=document.getElementById("gr-pagination"))==null||p.remove();return}const a=C();if(a.length<150){console.log("[Grimoire] Not enough text on page.");return}const s=h,d=[];for(let i=0;i<a.length;i+=s)d.push(a.slice(i,i+s));window.grChunks=d,window.grCurrentPage=0,window.grLorePages=[];const c=document.getElementById("gr-save");if(c){c.textContent="Grimoire'a Kaydet",c.disabled=!1,c.style.opacity="1";const i=c.cloneNode(!0);c.parentNode.replaceChild(i,c),i.addEventListener("click",S)}const l=document.getElementById("gr-mode-toggle");if(l){l.textContent=window.grCurrentMode==="formal_summary"?"Lore'a Dön":"Ciddi Özet";const i=l.cloneNode(!0);l.parentNode.replaceChild(i,l),i.addEventListener("click",async()=>{window.grCurrentMode=window.grCurrentMode==="formal_summary"?"lore":"formal_summary",i.textContent=window.grCurrentMode==="formal_summary"?"Lore'a Dön":"Ciddi Özet",window.grLorePages=[],document.getElementById("gr-lore").innerHTML="",await m(window.grCurrentPage)})}await m(0)}async function m(e){var o;P(),(o=document.getElementById("gr-pagination"))==null||o.remove();const t=window.grChunks[e],n=await chrome.runtime.sendMessage({type:y.TRANSFORM_TO_LORE,text:t,overrideStyle:window.grCurrentMode==="formal_summary"?"formal_summary":null});if(!n.ok){k(`Büyü bozuldu: ${n.error}`);return}window.grLorePages[e]=n.loreText,u()}function T(){const e=document.getElementById("gr-footer");if(!e)return;let t=document.getElementById("gr-pagination");t||(t=document.createElement("div"),t.id="gr-pagination",t.style.display="flex",t.style.justifyContent="space-between",t.style.alignItems="center",t.style.marginBottom="12px",t.style.fontSize="12px",t.style.color="#afa9ec",e.insertBefore(t,e.firstChild));const n=window.grChunks.length,o=window.grCurrentPage+1;t.innerHTML=`
    <button id="gr-prev" style="background:none; border:1px solid rgba(175,169,236,.3); color:#afa9ec; padding:4px 8px; border-radius:4px; font-size:11px; cursor:${o<=1?"default":"pointer"}; opacity:${o<=1?.3:1}">◄ Önceki</button>
    <span style="font-style:italic">Kitabe ${o} / ${n}</span>
    <button id="gr-next" style="background:none; border:1px solid rgba(175,169,236,.3); color:#afa9ec; padding:4px 8px; border-radius:4px; font-size:11px; cursor:${o>=n?"default":"pointer"}; opacity:${o>=n?.3:1}">Sonraki ►</button>
  `,document.getElementById("gr-prev").onclick=()=>{window.grCurrentPage>0&&(window.grCurrentPage--,u())},document.getElementById("gr-next").onclick=async()=>{window.grCurrentPage<n-1&&(window.grCurrentPage++,window.grLorePages[window.grCurrentPage]?u():await m(window.grCurrentPage))}}function u(){const e=window.grLorePages[window.grCurrentPage],t=I(),n=window.grLorePages.filter(Boolean).length*10,o=t+n;v(e,o),window.grChunks&&window.grChunks.length>1&&T()}chrome.storage.local.get(["session"],({session:e})=>{e!=null&&e.isActive&&setTimeout(w,800)});chrome.storage.onChanged.addListener(e=>{var t,n;e.session&&((t=e.session.newValue)!=null&&t.isActive)&&!((n=e.session.oldValue)!=null&&n.isActive)&&setTimeout(w,800)});async function S(){const e=document.getElementById("gr-save");if(!e)return;e.textContent="Kaydediliyor...",e.disabled=!0;const t=(window.grLorePages||[]).filter(Boolean).join("\\n\\n---\\n\\n"),n=document.body.scrollHeight-window.innerHeight,o=n>0?Math.min(100,window.scrollY/n*100):50,r=Math.floor((Date.now()-M)/1e3),a=(window.grLorePages||[]).filter(Boolean).length;let s=g.BASE_XP+Math.floor(o*g.SCROLL_MULTIPLIER)+a*10;r>=300&&(s+=g.LONG_READ_BONUS),o>=80&&(s+=g.DEEP_SCROLL_BONUS),s=Math.min(s,g.MAX_XP_PER_SAVE*2);const{character:d}=await chrome.storage.local.get(["character"]),c={id:crypto.randomUUID(),title:f||document.title.slice(0,80),url:window.location.href,loreText:t,xpEarned:s,savedAt:Date.now(),scrollPct:Math.floor(o),readSecs:r,prevLevel:(d==null?void 0:d.level)??1},l=await chrome.runtime.sendMessage({type:y.SAVE_SCROLL,entry:c});if(!l.ok){l.reason==="duplicate"?e.textContent="Zaten kaydedildi":e.textContent=`Hata: ${l.error??"bilinmiyor"}`;return}e.textContent=`+${s} XP kazandın!`,document.getElementById("gr-xp-preview").textContent="",l.leveledUp&&_(l.character.level)}function _(e){const t=document.createElement("div");t.style.cssText=`
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #0f0e17;
    border: 2px solid #7f77dd;
    border-radius: 12px;
    padding: 24px 32px;
    z-index: 2147483647;
    text-align: center;
    font-family: Georgia, serif;
    color: #e8e6d9;
    animation: gr-level-pop .4s ease;
  `,t.innerHTML=`
    <div style="font-size:13px;color:#afa9ec;letter-spacing:.1em;margin-bottom:8px">GRİMOİR</div>
    <div style="font-size:28px;font-weight:500;color:#7f77dd;margin-bottom:4px">Seviye ${e}</div>
    <div style="font-size:14px;color:#888780">Yeni bir kat açıldı.</div>
  `,document.body.appendChild(t),setTimeout(()=>t.remove(),3e3)}
