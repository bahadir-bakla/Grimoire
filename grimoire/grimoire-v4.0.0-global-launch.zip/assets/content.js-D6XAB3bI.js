import{M as v,D as x,a as E,X as u}from"./constants-B8XOycj8.js";import{t as a}from"./i18n-D2zGSiXN.js";let o="tr";chrome.storage.local.get(["settings"],({settings:e})=>{o=(e==null?void 0:e.appLanguage)||"tr"});chrome.storage.onChanged.addListener(e=>{var t,n;(n=(t=e.settings)==null?void 0:t.newValue)!=null&&n.appLanguage&&(o=e.settings.newValue.appLanguage)});console.log("[Grimoire] Content script loaded:",window.location.href);chrome.runtime.onMessage.addListener((e,t,n)=>(console.log("[Grimoire CS] Message received:",e.type),e.type===v.MONSTER_ATTACK&&(B(e),n({ok:!0})),e.type==="WEEKLY_BOSS"&&(C(e),n({ok:!0})),!0));function B(e){var l;(l=document.getElementById("gr-monster"))==null||l.remove();const{monster:t,xpLost:n,remainingXP:r}=e,s=document.createElement("div");s.id="gr-monster",s.innerHTML=`
    <div class="gr-monster-inner">
      <div class="gr-monster-eyebrow">${o==="en"&&t.titleEn||t.title}</div>
      <div class="gr-monster-name">${o==="en"&&t.nameEn||t.name}</div>
      <div class="gr-monster-msg">${o==="en"&&t.messageEn||t.message}</div>
      <div class="gr-monster-xp">
        <span class="gr-xp-lost">−${n} XP</span>
        <span class="gr-xp-remaining">${o==="en"?"Remaining":"Kalan"}: ${r} XP</span>
      </div>
      <div class="gr-monster-hp-wrap">
        <div class="gr-monster-hp-bar" id="gr-hp-bar"></div>
      </div>
      <button class="gr-monster-dismiss" id="gr-monster-ok">
        ${a("content.gotIt",o)}
      </button>
    </div>
  `,document.body.appendChild(s),requestAnimationFrame(()=>{const c=document.getElementById("gr-hp-bar");c&&(c.style.width="100%")}),document.getElementById("gr-monster-ok").addEventListener("click",()=>{s.classList.add("gr-monster-leaving"),setTimeout(()=>s.remove(),300)});const d=setTimeout(()=>{s.classList.add("gr-monster-leaving"),setTimeout(()=>s.remove(),300)},1e4);document.getElementById("gr-monster-ok").addEventListener("click",()=>{clearTimeout(d)},{once:!0})}function C(e){const{boss:t,weeklyScrolls:n,winXP:r}=e,s=document.createElement("div");s.id="gr-boss",s.innerHTML=`
    <div class="gr-boss-inner">
      <div class="gr-boss-label">${a("content.weeklyBoss",o)}</div>
      <div class="gr-boss-name">${o==="en"&&t.nameEn||t.name}</div>
      <div class="gr-boss-stats">
        ${o==="en"?`You completed ${n} scrolls this week.`:`Bu hafta ${n} scroll tamamladın.`}
        <br/>Boss HP: ${t.hp}/100
      </div>
      <div class="gr-boss-hp-track">
        <div class="gr-boss-hp-fill" style="width:${t.hp}%"></div>
      </div>
      <div class="gr-boss-actions">
        <button class="gr-boss-fight" id="gr-boss-fight">${o==="en"?`Fight (+${r} XP)`:`Savaş (+${r} XP)`}</button>
        <button class="gr-boss-flee" id="gr-boss-flee">${a("content.flee",o)}</button>
      </div>
      <div class="gr-boss-result" id="gr-boss-result" style="display:none"></div>
    </div>
  `,document.body.appendChild(s),document.getElementById("gr-boss-fight").addEventListener("click",async()=>{const d=Math.min(.9,n*.08+.2),l=Math.random()<d;document.getElementById("gr-boss-fight").disabled=!0,document.getElementById("gr-boss-flee").disabled=!0;const c=document.getElementById("gr-boss-result");c.style.display="block",l?(c.innerHTML=`
        <div class="gr-boss-win">
          ${o==="en"?`Victory! +${r} XP gained.`:`Zafer! +${r} XP kazandın.`}<br>
          <small>${o==="en"?"Weekly boss defeated.":"Haftalık boss yenildi."}</small>
        </div>
      `,await chrome.runtime.sendMessage({type:"BOSS_RESULT",won:!0,xpChange:r})):(c.innerHTML=`
        <div class="gr-boss-loss">
          ${o==="en"?"Defeat. 20% of your XP was wiped.":"Yenildin. XP'nin %20'si silindi."}<br>
          <small>${o==="en"?"Be stronger next week.":"Gelecek hafta daha güçlü ol."}</small>
        </div>
      `,await chrome.runtime.sendMessage({type:"BOSS_RESULT",won:!1,xpChange:0})),setTimeout(()=>{s.classList.add("gr-monster-leaving"),setTimeout(()=>s.remove(),300)},3e3)}),document.getElementById("gr-boss-flee").addEventListener("click",()=>{s.classList.add("gr-monster-leaving"),setTimeout(()=>s.remove(),300)})}function L(){const e=["article","main",'[role="main"]',".post-content",".article-content",".entry-content","#content"];let t=null;for(const d of e)if(t=document.querySelector(d),t)break;t=t??document.body;const n=t.cloneNode(!0);return["script","style","nav","footer","header","aside",".sidebar",".ad",".advertisement",".cookie-banner",".popup",'[aria-hidden="true"]'].forEach(d=>{n.querySelectorAll(d).forEach(l=>l.remove())}),(n.innerText??n.textContent??"").replace(/\s+/g," ").trim().slice(0,15e4)}function P(){return document.getElementById("gr-sidebar")}function k(){if(P())return;const e=document.createElement("div");e.id="gr-sidebar",e.innerHTML=`
    <div class="gr-sidebar-header">
      <span class="gr-sidebar-title">GRIMOIRE</span>
      <button class="gr-sidebar-close" id="gr-close" title="Kapat">×</button>
    </div>
    <div class="gr-sidebar-body" id="gr-body">
      <div class="gr-loading" id="gr-loading">
        <div class="gr-loading-dot"></div>
        <div class="gr-loading-dot"></div>
        <div class="gr-loading-dot"></div>
      </div>
      <div class="gr-lore-text" id="gr-lore" style="display:none"></div>
      <div class="gr-error" id="gr-error" style="display:none"></div>
    </div>
    <div class="gr-sidebar-footer" id="gr-footer" style="display:none">
      <div style="display:flex; gap:8px; margin-bottom:8px;">
        <button class="gr-save-btn" id="gr-save" style="flex:1">${a("content.saveGrimoire",o)}</button>
        <button id="gr-mode-toggle" style="flex:1; background:rgba(83,74,183,.2); border:1px solid rgba(83,74,183,.4); color:#afa9ec; border-radius:7px; font-size:12px; font-weight:500; cursor:pointer;" title="Hikaye ve Resmi Özet arasında geçiş yap">
          ${a("content.switchToFormal",o)}
        </button>
      </div>
      <div class="gr-xp-preview" id="gr-xp-preview"></div>
    </div>
  `,document.body.appendChild(e),document.getElementById("gr-close").addEventListener("click",()=>{e.classList.add("gr-sidebar-closing"),setTimeout(()=>e.remove(),250)})}function I(){document.getElementById("gr-loading").style.display="flex",document.getElementById("gr-lore").style.display="none",document.getElementById("gr-error").style.display="none",document.getElementById("gr-footer").style.display="none"}function w(e,t){document.getElementById("gr-loading").style.display="none",document.getElementById("gr-error").style.display="none";const n=document.getElementById("gr-lore");n.style.display="block";const r=e.split(`

`).filter(Boolean);n.innerHTML=r.map(s=>`<p>${s.trim()}</p>`).join(""),document.getElementById("gr-footer").style.display="block",document.getElementById("gr-xp-preview").textContent=`+${t} XP kazanacaksın`}function T(e){document.getElementById("gr-loading").style.display="none",document.getElementById("gr-lore").style.display="none";const t=document.getElementById("gr-error");t.style.display="block",t.textContent=e}function M(){const e=document.body.scrollHeight-window.innerHeight,t=e>0?Math.min(100,window.scrollY/e*100):50;return Math.floor(100+t*3)}let b=null,$=Date.now();async function h(){var f;const e=window.location.href;if(e.startsWith("chrome://")||e.startsWith("chrome-extension://")||e.startsWith("about:")||e.startsWith("data:")||x.some(i=>e.includes(i)))return;const{session:n}=await chrome.storage.local.get(["session"]);if(!(n!=null&&n.isActive))return;window.grCurrentMode=n.mode||"lore",b=document.title.slice(0,80),k();const{grimoire:r}=await chrome.storage.local.get(["grimoire"]),s=(r??[]).find(i=>i.url===e);if(s){w(s.loreText,0);const i=document.getElementById("gr-save");i&&(i.textContent=a("content.alreadySaved",o),i.disabled=!0,i.style.opacity="0.5"),(f=document.getElementById("gr-pagination"))==null||f.remove();return}const d=L();if(d.length<150){console.log("[Grimoire] Not enough text on page.");return}const l=E,c=[];for(let i=0;i<d.length;i+=l)c.push(d.slice(i,i+l));window.grChunks=c,window.grCurrentPage=0,window.grLorePages=[];const m=document.getElementById("gr-save");if(m){m.textContent=a("content.saveGrimoire",o),m.disabled=!1,m.style.opacity="1";const i=m.cloneNode(!0);m.parentNode.replaceChild(i,m),i.addEventListener("click",_)}const g=document.getElementById("gr-mode-toggle");if(g){g.textContent=window.grCurrentMode==="formal_summary"?a("content.switchToLore",o):a("content.switchToFormal",o);const i=g.cloneNode(!0);g.parentNode.replaceChild(i,g),i.addEventListener("click",async()=>{window.grCurrentMode=window.grCurrentMode==="formal_summary"?"lore":"formal_summary",i.textContent=window.grCurrentMode==="formal_summary"?a("content.switchToLore",o):a("content.switchToFormal",o),window.grLorePages=[],document.getElementById("gr-lore").innerHTML="",await p(window.grCurrentPage)})}await p(0)}async function p(e){var r;I(),(r=document.getElementById("gr-pagination"))==null||r.remove();const t=window.grChunks[e],n=await chrome.runtime.sendMessage({type:v.TRANSFORM_TO_LORE,text:t,overrideStyle:window.grCurrentMode==="formal_summary"?"formal_summary":null});if(!n.ok){T(`${a("content.spellFailed",o)} ${n.error}`);return}window.grLorePages[e]=n.loreText,y()}function S(){const e=document.getElementById("gr-footer");if(!e)return;let t=document.getElementById("gr-pagination");t||(t=document.createElement("div"),t.id="gr-pagination",t.style.display="flex",t.style.justifyContent="space-between",t.style.alignItems="center",t.style.marginBottom="12px",t.style.fontSize="12px",t.style.color="#afa9ec",e.insertBefore(t,e.firstChild));const n=window.grChunks.length,r=window.grCurrentPage+1;t.innerHTML=`
    <button id="gr-prev" style="background:none; border:1px solid rgba(175,169,236,.3); color:#afa9ec; padding:4px 8px; border-radius:4px; font-size:11px; cursor:${r<=1?"default":"pointer"}; opacity:${r<=1?.3:1}">${a("content.prev",o)}</button>
    <span style="font-style:italic">${a("content.chunk",o)} ${r} / ${n}</span>
    <button id="gr-next" style="background:none; border:1px solid rgba(175,169,236,.3); color:#afa9ec; padding:4px 8px; border-radius:4px; font-size:11px; cursor:${r>=n?"default":"pointer"}; opacity:${r>=n?.3:1}">${a("content.next",o)}</button>
  `,document.getElementById("gr-prev").onclick=()=>{window.grCurrentPage>0&&(window.grCurrentPage--,y())},document.getElementById("gr-next").onclick=async()=>{window.grCurrentPage<n-1&&(window.grCurrentPage++,window.grLorePages[window.grCurrentPage]?y():await p(window.grCurrentPage))}}function y(){const e=window.grLorePages[window.grCurrentPage],t=M(),n=window.grLorePages.filter(Boolean).length*10,r=t+n;w(e,r),window.grChunks&&window.grChunks.length>1&&S()}chrome.storage.local.get(["session"],({session:e})=>{e!=null&&e.isActive&&setTimeout(h,800)});chrome.storage.onChanged.addListener(e=>{var t,n;e.session&&((t=e.session.newValue)!=null&&t.isActive)&&!((n=e.session.oldValue)!=null&&n.isActive)&&setTimeout(h,800)});async function _(){const e=document.getElementById("gr-save");if(!e)return;e.textContent=a("content.saving",o),e.disabled=!0;const t=(window.grLorePages||[]).filter(Boolean).join("\\n\\n---\\n\\n"),n=document.body.scrollHeight-window.innerHeight,r=n>0?Math.min(100,window.scrollY/n*100):50,s=Math.floor((Date.now()-$)/1e3),d=(window.grLorePages||[]).filter(Boolean).length;let l=u.BASE_XP+Math.floor(r*u.SCROLL_MULTIPLIER)+d*10;s>=300&&(l+=u.LONG_READ_BONUS),r>=80&&(l+=u.DEEP_SCROLL_BONUS),l=Math.min(l,u.MAX_XP_PER_SAVE*2);const{character:c}=await chrome.storage.local.get(["character"]),m={id:crypto.randomUUID(),title:b||document.title.slice(0,80),url:window.location.href,loreText:t,xpEarned:l,savedAt:Date.now(),scrollPct:Math.floor(r),readSecs:s,prevLevel:(c==null?void 0:c.level)??1},g=await chrome.runtime.sendMessage({type:v.SAVE_SCROLL,entry:m});if(!g.ok){g.reason==="duplicate"?e.textContent=a("content.alreadySaved",o):e.textContent=`${a("content.saveError",o)} ${g.error??"bilinmiyor"}`;return}e.textContent=`+${l} XP`,document.getElementById("gr-xp-preview").textContent="",g.leveledUp&&A(g.character.level)}function A(e){const t=document.createElement("div");t.style.cssText=`
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #0f0e17;
    border: 2px solid #7f77dd;
    border-radius: 12px;
    padding: 24px 32px;
    z-index: 2147483647;
    text-align: center;
    font-family: Georgia, serif;
    color: #e8e6d9;
    animation: gr-level-pop .4s ease;
  `,t.innerHTML=`
    <div style="font-size:13px;color:#afa9ec;letter-spacing:.1em;margin-bottom:8px">GRİMOİR</div>
    <div style="font-size:28px;font-weight:500;color:#7f77dd;margin-bottom:4px">Seviye ${e}</div>
    <div style="font-size:14px;color:#888780">Yeni bir kat açıldı.</div>
  `,document.body.appendChild(t),setTimeout(()=>t.remove(),3e3)}
