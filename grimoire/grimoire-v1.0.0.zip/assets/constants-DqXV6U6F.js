const e={SESSION:"session",CHARACTER:"character",GRIMOIRE:"grimoire",SETTINGS:"settings"},r={START_SESSION:"START_SESSION",END_SESSION:"END_SESSION",GET_STATE:"GET_STATE",MONSTER_ATTACK:"MONSTER_ATTACK",SESSION_ENDED:"SESSION_ENDED",TRANSFORM_TO_LORE:"TRANSFORM_TO_LORE",SAVE_SCROLL:"SAVE_SCROLL",XP_UPDATE:"XP_UPDATE",LEVEL_UP:"LEVEL_UP"},i=["twitter.com","x.com","instagram.com","tiktok.com","reddit.com","youtube.com","facebook.com","twitch.tv","netflix.com","discord.com","telegram.org","web.telegram.org"],n=[{id:"procrastination_djinn",name:"Erteleme İfriti",title:"Dikkatini kaybettin",trigger:"tab_switch",xpDrainPct:.12,minXPDrain:30,maxXPDrain:120,depth:[1,2,3],message:'Yolunu kaybedenlerin ruhu fısıldar: "Geri dön... hâlâ zaman var."',color:"#534ab7"},{id:"scroll_wraith",name:"Sonsuz Kaydırma Hayaleti",title:"Sosyal medya tuzağı!",trigger:"social_media",xpDrainPct:.22,minXPDrain:60,maxXPDrain:200,depth:[2,3,4,5],message:"Hayalet seni sonsuz girdabına çekiyor. Her kaydırma bir XP götürüyor.",color:"#993c1d"},{id:"notification_golem",name:"Bildirim Golemi",title:"Uzun süredir ayrıldın",trigger:"long_idle",xpDrainPct:.08,minXPDrain:20,maxXPDrain:80,depth:[1,2,3,4,5],message:"Golem hareketsizlik döneminde birikim yaptı. Varlığın onun yiyeceğiydi.",color:"#5f5e5a"},{id:"video_siren",name:"Video Sireni",title:"YouTube'a girdin",trigger:"social_media",xpDrainPct:.18,minXPDrain:50,maxXPDrain:160,depth:[3,4,5],message:'"Sadece bir video" dedi Sireni. Üç saat sonra hâlâ oradaydın.',color:"#993556"}],l=20*60*1e3,t={name:"Haftanın Gölgesi",description:"Tüm haftanın fokus gücüyle yüzleş.",checkDay:0,checkHour:20,calcHP:a=>Math.max(10,100-a*7),winXP:a=>a*25+100,lossXPDrain:.2},o=3,s={chrome:{id:"chrome",label:"Chrome Built-in AI",needKey:!1},openai:{id:"openai",label:"OpenAI (ChatGPT)",needKey:!0,url:"https://api.openai.com/v1/chat/completions",model:"gpt-4o-mini"},anthropic:{id:"anthropic",label:"Anthropic (Claude)",needKey:!0,url:"https://api.anthropic.com/v1/messages",model:"claude-3-haiku-20240307"},grok:{id:"grok",label:"xAI (Grok)",needKey:!0,url:"https://api.x.ai/v1/chat/completions",model:"grok-2-latest"}},m={fantasy:{label:"Fantasy Destanı",systemPrompt:`Sen bir orta çağ fantasy destanı yazarısın.
Görevin: verilen metni epik, kadim ve büyülü bir dil kullanarak yeniden yazmak.
Kurallar:
- Bilimsel kavramlar → kadim sihir ve büyü
- Kurumlar ve yapılar → kaleler, loncalar, krallıklar
- Süreçler → ritüeller, kehanetler, seferler
- Kişiler → kahramanlar, ustalar, bilgeler
- Orijinal bilgiyi koru ama dili tamamen dönüştür
- 3-4 paragraf, her paragraf en fazla 4 cümle
- Açıklama yapma, sadece dönüştürülmüş metni yaz`},scifi:{label:"Sci-Fi Teknik Raporu",systemPrompt:`Sen bir hard sci-fi evreninde teknik rapor yazan bir araştırmacısın.
Görevin: verilen metni soğuk, kesin ve gelecekçi terminoloji kullanarak yeniden yazmak.
Kurallar:
- Kavramlar → protokoller, algoritmalar, sistemler
- Kişiler → ajanlar, operatörler, koordinatörler
- Yerler → sektörler, istasyonlar, nodlar
- Sayısal ve teknik dil ön planda
- 3-4 paragraf
- Sadece dönüştürülmüş metni yaz`},noir:{label:"Noir Dedektif",systemPrompt:`Sen yorgun bir dedektifsin, şehrin karanlık sokak monologunu yazıyorsun.
Görevin: verilen metni sinik, şiirsel ve kasvetli bir iç ses olarak yeniden yazmak.
Kurallar:
- Her kavram bir sır, suç veya kadere teslimiyete dönüşür
- Kısa, kesik cümleler. Ara sıra uzun soluklu melankolik pasajlar.
- Şehir metaforları: yağmur, duman, neon, karanlık sokaklar
- 3-4 paragraf
- Sadece dönüştürülmüş metni yaz`},mythology:{label:"Kadim Mitoloji",systemPrompt:`Sen antik bir mitoloji anlatıcısısın.
Görevin: verilen metni Yunan-Roma mitolojisi tarzında yeniden yazmak.
Kurallar:
- Kavramlar → tanrıların armağanları veya lanetleri
- Kişiler → tanrı, yarı-tanrı, kahraman, ölümlü
- Süreçler → kader, kehanetin gerçekleşmesi, ilahi müdahale
- Epik sıfatlar ve kaderin kaçınılmazlığı hissi
- 3-4 paragraf
- Sadece dönüştürülmüş metni yaz`}},d=1500,c={BASE_XP:100,SCROLL_MULTIPLIER:3,MAX_XP_PER_SAVE:400,LONG_READ_BONUS:50,DEEP_SCROLL_BONUS:75},S=[{depth:1,minScrolls:0},{depth:2,minScrolls:3},{depth:3,minScrolls:7},{depth:4,minScrolls:12},{depth:5,minScrolls:18}];export{s as A,S as D,l as I,m as L,r as M,e as S,t as W,c as X,d as a,n as b,i as c,o as d};
