import{M as c,a as g,X as d}from"./constants-DqXV6U6F.js";console.log("[Grimoire] Content script loaded:",window.location.href);chrome.runtime.onMessage.addListener((e,t,o)=>(console.log("[Grimoire CS] Message received:",e.type),e.type===c.MONSTER_ATTACK&&(m(e),o({ok:!0})),e.type==="WEEKLY_BOSS"&&(u(e),o({ok:!0})),!0));function m(e){var i;(i=document.getElementById("gr-monster"))==null||i.remove();const{monster:t,xpLost:o,remainingXP:s}=e,n=document.createElement("div");n.id="gr-monster",n.innerHTML=`
    <div class="gr-monster-inner">
      <div class="gr-monster-eyebrow">${t.title}</div>
      <div class="gr-monster-name">${t.name}</div>
      <div class="gr-monster-msg">${t.message}</div>
      <div class="gr-monster-xp">
        <span class="gr-xp-lost">−${o} XP</span>
        <span class="gr-xp-remaining">Kalan: ${s} XP</span>
      </div>
      <div class="gr-monster-hp-wrap">
        <div class="gr-monster-hp-bar" id="gr-hp-bar"></div>
      </div>
      <button class="gr-monster-dismiss" id="gr-monster-ok">
        Anladım, geri dönüyorum
      </button>
    </div>
  `,document.body.appendChild(n),requestAnimationFrame(()=>{const a=document.getElementById("gr-hp-bar");a&&(a.style.width="100%")}),document.getElementById("gr-monster-ok").addEventListener("click",()=>{n.classList.add("gr-monster-leaving"),setTimeout(()=>n.remove(),300)});const r=setTimeout(()=>{n.classList.add("gr-monster-leaving"),setTimeout(()=>n.remove(),300)},1e4);document.getElementById("gr-monster-ok").addEventListener("click",()=>{clearTimeout(r)},{once:!0})}function u(e){const{boss:t,weeklyScrolls:o,winXP:s}=e,n=document.createElement("div");n.id="gr-boss",n.innerHTML=`
    <div class="gr-boss-inner">
      <div class="gr-boss-label">HAFTALIK YÜZLEŞME</div>
      <div class="gr-boss-name">${t.name}</div>
      <div class="gr-boss-stats">
        Bu hafta ${o} scroll tamamladın.
        Boss HP: ${t.hp}/100
      </div>
      <div class="gr-boss-hp-track">
        <div class="gr-boss-hp-fill" style="width:${t.hp}%"></div>
      </div>
      <div class="gr-boss-actions">
        <button class="gr-boss-fight" id="gr-boss-fight">Savaş (+${s} XP)</button>
        <button class="gr-boss-flee" id="gr-boss-flee">Kaç</button>
      </div>
      <div class="gr-boss-result" id="gr-boss-result" style="display:none"></div>
    </div>
  `,document.body.appendChild(n),document.getElementById("gr-boss-fight").addEventListener("click",async()=>{const r=Math.min(.9,o*.08+.2),i=Math.random()<r;document.getElementById("gr-boss-fight").disabled=!0,document.getElementById("gr-boss-flee").disabled=!0;const a=document.getElementById("gr-boss-result");a.style.display="block",i?(a.innerHTML=`
        <div class="gr-boss-win">
          Zafer! +${s} XP kazandın.<br>
          <small>Haftalık boss yenildi.</small>
        </div>
      `,await chrome.runtime.sendMessage({type:"BOSS_RESULT",won:!0,xpChange:s})):(a.innerHTML=`
        <div class="gr-boss-loss">
          Yenildin. XP'nin %20'si silindi.<br>
          <small>Gelecek hafta daha güçlü ol.</small>
        </div>
      `,await chrome.runtime.sendMessage({type:"BOSS_RESULT",won:!1,xpChange:0})),setTimeout(()=>{n.classList.add("gr-monster-leaving"),setTimeout(()=>n.remove(),300)},3e3)}),document.getElementById("gr-boss-flee").addEventListener("click",()=>{n.classList.add("gr-monster-leaving"),setTimeout(()=>n.remove(),300)})}function v(){const e=["article","main",'[role="main"]',".post-content",".article-content",".entry-content","#content"];let t=null;for(const r of e)if(t=document.querySelector(r),t)break;t=t??document.body;const o=t.cloneNode(!0);return["script","style","nav","footer","header","aside",".sidebar",".ad",".advertisement",".cookie-banner",".popup",'[aria-hidden="true"]'].forEach(r=>{o.querySelectorAll(r).forEach(i=>i.remove())}),(o.innerText??o.textContent??"").replace(/\s+/g," ").trim().slice(0,g)}function p(){return document.getElementById("gr-sidebar")}function y(){if(p())return;const e=document.createElement("div");e.id="gr-sidebar",e.innerHTML=`
    <div class="gr-sidebar-header">
      <span class="gr-sidebar-title">GRIMOIRE</span>
      <button class="gr-sidebar-close" id="gr-close" title="Kapat">×</button>
    </div>
    <div class="gr-sidebar-body" id="gr-body">
      <div class="gr-loading" id="gr-loading">
        <div class="gr-loading-dot"></div>
        <div class="gr-loading-dot"></div>
        <div class="gr-loading-dot"></div>
      </div>
      <div class="gr-lore-text" id="gr-lore" style="display:none"></div>
      <div class="gr-error" id="gr-error" style="display:none"></div>
    </div>
    <div class="gr-sidebar-footer" id="gr-footer" style="display:none">
      <button class="gr-save-btn" id="gr-save">Grimoire'a Kaydet</button>
      <div class="gr-xp-preview" id="gr-xp-preview"></div>
    </div>
  `,document.body.appendChild(e),document.getElementById("gr-close").addEventListener("click",()=>{e.classList.add("gr-sidebar-closing"),setTimeout(()=>e.remove(),250)})}function b(){document.getElementById("gr-loading").style.display="flex",document.getElementById("gr-lore").style.display="none",document.getElementById("gr-error").style.display="none",document.getElementById("gr-footer").style.display="none"}function f(e,t){document.getElementById("gr-loading").style.display="none",document.getElementById("gr-error").style.display="none";const o=document.getElementById("gr-lore");o.style.display="block";const s=e.split(`

`).filter(Boolean);o.innerHTML=s.map(n=>`<p>${n.trim()}</p>`).join(""),document.getElementById("gr-footer").style.display="block",document.getElementById("gr-xp-preview").textContent=`+${t} XP kazanacaksın`}function h(e){document.getElementById("gr-loading").style.display="none",document.getElementById("gr-lore").style.display="none";const t=document.getElementById("gr-error");t.style.display="block",t.textContent=e}function E(){const e=document.body.scrollHeight-window.innerHeight,t=e>0?Math.min(100,window.scrollY/e*100):50;return Math.floor(100+t*3)}async function x(){const e=window.location.href;if(e.startsWith("chrome://")||e.startsWith("chrome-extension://")||e.startsWith("about:")||e.startsWith("data:")){console.log("[Grimoire] Internal page, skipping");return}const{session:t}=await chrome.storage.local.get(["session"]);if(!(t!=null&&t.isActive)){console.log("[Grimoire] Session ended before transform completed");return}const o=v();if(o.length<150){console.log("[Grimoire] Not enough text on page, skipping transform");return}y(),b(),document.title.slice(0,80);const s=await chrome.runtime.sendMessage({type:c.TRANSFORM_TO_LORE,text:o});if(!s.ok){h(`Lore dönüşümü başarısız: ${s.error}`);return}s.loreText;const n=E();f(s.loreText,n),document.getElementById("gr-save").addEventListener("click",()=>B(s.loreText))}chrome.storage.local.get(["session"],({session:e})=>{e!=null&&e.isActive&&setTimeout(x,800)});let w=Date.now();async function B(e){const t=document.getElementById("gr-save");if(!t)return;t.textContent="Kaydediliyor...",t.disabled=!0;const o=document.body.scrollHeight-window.innerHeight,s=o>0?Math.min(100,window.scrollY/o*100):50,n=Math.floor((Date.now()-w)/1e3);let r=d.BASE_XP+Math.floor(s*d.SCROLL_MULTIPLIER);n>=300&&(r+=d.LONG_READ_BONUS),s>=80&&(r+=d.DEEP_SCROLL_BONUS),r=Math.min(r,d.MAX_XP_PER_SAVE);const{character:i}=await chrome.storage.local.get(["character"]),a={id:crypto.randomUUID(),title:document.title.slice(0,80),url:window.location.href,loreText:e,xpEarned:r,savedAt:Date.now(),scrollPct:Math.floor(s),readSecs:n,prevLevel:(i==null?void 0:i.level)??1},l=await chrome.runtime.sendMessage({type:c.SAVE_SCROLL,entry:a});if(!l.ok){l.reason==="duplicate"?t.textContent="Zaten kaydedildi":t.textContent=`Hata: ${l.error??"bilinmiyor"}`;return}t.textContent=`+${r} XP kazandın!`,document.getElementById("gr-xp-preview").textContent="",l.leveledUp&&L(l.character.level)}function L(e){const t=document.createElement("div");t.style.cssText=`
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #0f0e17;
    border: 2px solid #7f77dd;
    border-radius: 12px;
    padding: 24px 32px;
    z-index: 2147483647;
    text-align: center;
    font-family: Georgia, serif;
    color: #e8e6d9;
    animation: gr-level-pop .4s ease;
  `,t.innerHTML=`
    <div style="font-size:13px;color:#afa9ec;letter-spacing:.1em;margin-bottom:8px">GRİMOİR</div>
    <div style="font-size:28px;font-weight:500;color:#7f77dd;margin-bottom:4px">Seviye ${e}</div>
    <div style="font-size:14px;color:#888780">Yeni bir kat açıldı.</div>
  `,document.body.appendChild(t),setTimeout(()=>t.remove(),3e3)}
