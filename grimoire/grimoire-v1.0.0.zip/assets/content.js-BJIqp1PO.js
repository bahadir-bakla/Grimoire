import{M as c,D as m,a as g,X as d}from"./constants-Brq4HeM5.js";console.log("[Grimoire] Content script loaded:",window.location.href);chrome.runtime.onMessage.addListener((e,t,o)=>(console.log("[Grimoire CS] Message received:",e.type),e.type===c.MONSTER_ATTACK&&(u(e),o({ok:!0})),e.type==="WEEKLY_BOSS"&&(v(e),o({ok:!0})),!0));function u(e){var i;(i=document.getElementById("gr-monster"))==null||i.remove();const{monster:t,xpLost:o,remainingXP:r}=e,n=document.createElement("div");n.id="gr-monster",n.innerHTML=`
    <div class="gr-monster-inner">
      <div class="gr-monster-eyebrow">${t.title}</div>
      <div class="gr-monster-name">${t.name}</div>
      <div class="gr-monster-msg">${t.message}</div>
      <div class="gr-monster-xp">
        <span class="gr-xp-lost">−${o} XP</span>
        <span class="gr-xp-remaining">Kalan: ${r} XP</span>
      </div>
      <div class="gr-monster-hp-wrap">
        <div class="gr-monster-hp-bar" id="gr-hp-bar"></div>
      </div>
      <button class="gr-monster-dismiss" id="gr-monster-ok">
        Anladım, geri dönüyorum
      </button>
    </div>
  `,document.body.appendChild(n),requestAnimationFrame(()=>{const a=document.getElementById("gr-hp-bar");a&&(a.style.width="100%")}),document.getElementById("gr-monster-ok").addEventListener("click",()=>{n.classList.add("gr-monster-leaving"),setTimeout(()=>n.remove(),300)});const s=setTimeout(()=>{n.classList.add("gr-monster-leaving"),setTimeout(()=>n.remove(),300)},1e4);document.getElementById("gr-monster-ok").addEventListener("click",()=>{clearTimeout(s)},{once:!0})}function v(e){const{boss:t,weeklyScrolls:o,winXP:r}=e,n=document.createElement("div");n.id="gr-boss",n.innerHTML=`
    <div class="gr-boss-inner">
      <div class="gr-boss-label">HAFTALIK YÜZLEŞME</div>
      <div class="gr-boss-name">${t.name}</div>
      <div class="gr-boss-stats">
        Bu hafta ${o} scroll tamamladın.
        Boss HP: ${t.hp}/100
      </div>
      <div class="gr-boss-hp-track">
        <div class="gr-boss-hp-fill" style="width:${t.hp}%"></div>
      </div>
      <div class="gr-boss-actions">
        <button class="gr-boss-fight" id="gr-boss-fight">Savaş (+${r} XP)</button>
        <button class="gr-boss-flee" id="gr-boss-flee">Kaç</button>
      </div>
      <div class="gr-boss-result" id="gr-boss-result" style="display:none"></div>
    </div>
  `,document.body.appendChild(n),document.getElementById("gr-boss-fight").addEventListener("click",async()=>{const s=Math.min(.9,o*.08+.2),i=Math.random()<s;document.getElementById("gr-boss-fight").disabled=!0,document.getElementById("gr-boss-flee").disabled=!0;const a=document.getElementById("gr-boss-result");a.style.display="block",i?(a.innerHTML=`
        <div class="gr-boss-win">
          Zafer! +${r} XP kazandın.<br>
          <small>Haftalık boss yenildi.</small>
        </div>
      `,await chrome.runtime.sendMessage({type:"BOSS_RESULT",won:!0,xpChange:r})):(a.innerHTML=`
        <div class="gr-boss-loss">
          Yenildin. XP'nin %20'si silindi.<br>
          <small>Gelecek hafta daha güçlü ol.</small>
        </div>
      `,await chrome.runtime.sendMessage({type:"BOSS_RESULT",won:!1,xpChange:0})),setTimeout(()=>{n.classList.add("gr-monster-leaving"),setTimeout(()=>n.remove(),300)},3e3)}),document.getElementById("gr-boss-flee").addEventListener("click",()=>{n.classList.add("gr-monster-leaving"),setTimeout(()=>n.remove(),300)})}function p(){const e=["article","main",'[role="main"]',".post-content",".article-content",".entry-content","#content"];let t=null;for(const s of e)if(t=document.querySelector(s),t)break;t=t??document.body;const o=t.cloneNode(!0);return["script","style","nav","footer","header","aside",".sidebar",".ad",".advertisement",".cookie-banner",".popup",'[aria-hidden="true"]'].forEach(s=>{o.querySelectorAll(s).forEach(i=>i.remove())}),(o.innerText??o.textContent??"").replace(/\s+/g," ").trim().slice(0,g)}function y(){return document.getElementById("gr-sidebar")}function b(){if(y())return;const e=document.createElement("div");e.id="gr-sidebar",e.innerHTML=`
    <div class="gr-sidebar-header">
      <span class="gr-sidebar-title">GRIMOIRE</span>
      <button class="gr-sidebar-close" id="gr-close" title="Kapat">×</button>
    </div>
    <div class="gr-sidebar-body" id="gr-body">
      <div class="gr-loading" id="gr-loading">
        <div class="gr-loading-dot"></div>
        <div class="gr-loading-dot"></div>
        <div class="gr-loading-dot"></div>
      </div>
      <div class="gr-lore-text" id="gr-lore" style="display:none"></div>
      <div class="gr-error" id="gr-error" style="display:none"></div>
    </div>
    <div class="gr-sidebar-footer" id="gr-footer" style="display:none">
      <button class="gr-save-btn" id="gr-save">Grimoire'a Kaydet</button>
      <div class="gr-xp-preview" id="gr-xp-preview"></div>
    </div>
  `,document.body.appendChild(e),document.getElementById("gr-close").addEventListener("click",()=>{e.classList.add("gr-sidebar-closing"),setTimeout(()=>e.remove(),250)})}function f(){document.getElementById("gr-loading").style.display="flex",document.getElementById("gr-lore").style.display="none",document.getElementById("gr-error").style.display="none",document.getElementById("gr-footer").style.display="none"}function h(e,t){document.getElementById("gr-loading").style.display="none",document.getElementById("gr-error").style.display="none";const o=document.getElementById("gr-lore");o.style.display="block";const r=e.split(`

`).filter(Boolean);o.innerHTML=r.map(n=>`<p>${n.trim()}</p>`).join(""),document.getElementById("gr-footer").style.display="block",document.getElementById("gr-xp-preview").textContent=`+${t} XP kazanacaksın`}function E(e){document.getElementById("gr-loading").style.display="none",document.getElementById("gr-lore").style.display="none";const t=document.getElementById("gr-error");t.style.display="block",t.textContent=e}function x(){const e=document.body.scrollHeight-window.innerHeight,t=e>0?Math.min(100,window.scrollY/e*100):50;return Math.floor(100+t*3)}async function w(){const e=window.location.href;if(e.startsWith("chrome://")||e.startsWith("chrome-extension://")||e.startsWith("about:")||e.startsWith("data:")){console.log("[Grimoire] Internal page, skipping");return}if(m.some(a=>e.includes(a))){console.log("[Grimoire] Distraction domain, content.js will let the monster handle it.");return}const{session:o}=await chrome.storage.local.get(["session"]);if(!(o!=null&&o.isActive)){console.log("[Grimoire] Session ended before transform completed");return}const r=p();if(r.length<150){console.log("[Grimoire] Not enough text on page, skipping transform");return}b(),f(),document.title.slice(0,80);const n=await chrome.runtime.sendMessage({type:c.TRANSFORM_TO_LORE,text:r});if(!n.ok){E(`Lore dönüşümü başarısız: ${n.error}`);return}n.loreText;const s=x();h(n.loreText,s),document.getElementById("gr-save").addEventListener("click",()=>L(n.loreText))}chrome.storage.local.get(["session"],({session:e})=>{e!=null&&e.isActive&&setTimeout(w,800)});let B=Date.now();async function L(e){const t=document.getElementById("gr-save");if(!t)return;t.textContent="Kaydediliyor...",t.disabled=!0;const o=document.body.scrollHeight-window.innerHeight,r=o>0?Math.min(100,window.scrollY/o*100):50,n=Math.floor((Date.now()-B)/1e3);let s=d.BASE_XP+Math.floor(r*d.SCROLL_MULTIPLIER);n>=300&&(s+=d.LONG_READ_BONUS),r>=80&&(s+=d.DEEP_SCROLL_BONUS),s=Math.min(s,d.MAX_XP_PER_SAVE);const{character:i}=await chrome.storage.local.get(["character"]),a={id:crypto.randomUUID(),title:document.title.slice(0,80),url:window.location.href,loreText:e,xpEarned:s,savedAt:Date.now(),scrollPct:Math.floor(r),readSecs:n,prevLevel:(i==null?void 0:i.level)??1},l=await chrome.runtime.sendMessage({type:c.SAVE_SCROLL,entry:a});if(!l.ok){l.reason==="duplicate"?t.textContent="Zaten kaydedildi":t.textContent=`Hata: ${l.error??"bilinmiyor"}`;return}t.textContent=`+${s} XP kazandın!`,document.getElementById("gr-xp-preview").textContent="",l.leveledUp&&I(l.character.level)}function I(e){const t=document.createElement("div");t.style.cssText=`
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #0f0e17;
    border: 2px solid #7f77dd;
    border-radius: 12px;
    padding: 24px 32px;
    z-index: 2147483647;
    text-align: center;
    font-family: Georgia, serif;
    color: #e8e6d9;
    animation: gr-level-pop .4s ease;
  `,t.innerHTML=`
    <div style="font-size:13px;color:#afa9ec;letter-spacing:.1em;margin-bottom:8px">GRİMOİR</div>
    <div style="font-size:28px;font-weight:500;color:#7f77dd;margin-bottom:4px">Seviye ${e}</div>
    <div style="font-size:14px;color:#888780">Yeni bir kat açıldı.</div>
  `,document.body.appendChild(t),setTimeout(()=>t.remove(),3e3)}
