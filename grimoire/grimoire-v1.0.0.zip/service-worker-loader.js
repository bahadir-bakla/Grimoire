import './assets/service-worker.js-CdELZTIm.js';
